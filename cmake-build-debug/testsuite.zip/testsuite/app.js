function generateDynamicContent() {
    document.getElementById("dyn").innerHTML = new Date().toLocaleString();
}